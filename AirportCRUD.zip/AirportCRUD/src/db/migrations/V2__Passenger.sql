CREATE TABLE Passenger (
    PassengerID INT PRIMARY KEY,
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    CheckInDateTime TIMESTAMP NOT NULL,
    CheckInLocationID INT NOT NULL,
    FOREIGN KEY (CheckInLocationID) REFERENCES CheckInLocation(CheckInLocationID)
);